<?=content_open('Beranda')?>
    <?=$this->session->flashdata('info')?>
<?=content_close()?>