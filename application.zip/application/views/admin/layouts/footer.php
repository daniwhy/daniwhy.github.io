 <footer>
  <div class="pull-right">
    
    <strong>Copyright &copy; 2020 | Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
  </div>
  <div class="clearfix"></div>
</footer>