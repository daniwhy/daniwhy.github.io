<!DOCTYPE html>
<html lang="en">
<?php include 'view.php'?>
	<?php include 'head.php'?>
	  	<?php include 'body.php';?>
	<?php
		if(isset($js)){
			echo $js;
		}
	?>
	</body>
</html>
